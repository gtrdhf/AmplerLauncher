# Eaglercraft 1.20
NOTE: PLEASE FORK THIS PROJECT!!! 🍴
-
## 😎 Let me introduce you to Eaglercraft 1.20!


### Eaglercraft 1.20 is Eaglercraft BUT written in Python and will be ported to HTML! 🔌


## 🎮 Eaglercraft 1.20 is different from other Eaglercraft clients because:


### **Instant boot time** ⏩
### Newer version of Eaglercraft ✨
### Written in Python and HTML , CSS AND JS Cuz why not🐍
### More skins 👕
### Pets for your avatar 🐶
### Infinite world 🌍
### Runs smoothly on Chromebooks 💻


# Devs 🛠️
## 👨‍💻 AR-DEV-1

### 🌐 Paved the way for Eagler development console to code in diverse programming languages
### 🐛 Meticulously fixed bugs
### 📁 Initiated the repository
### 🎮 Imported assets for 1.14
### 💥 Holds the title of "OP" (Overpowered) in the project
### 🤼 Tries to bring the Eaglercraft community together
### 🚀 The best brother i ever had - FlameV3

## 👨‍💻 BtPlayzX
### 🚀 Designed the Eaglercraft Launcher using Python
### 🛠️ Works on enhancing his Eaglercraft Launcher
### 🌐 Expanded the server list functionality
### 👑 Carries the title of "OP"
### 🤼 Tries to bring the Eaglercraft community together
### 🐍 Very skilled at Python
### 😄 Knows how to code at a young age
### 🐛 Meticulously fixed bugs
### 🌟 Elevated our website's quality
### 🎮 Made his own gaming development organization (via Fungang Entertainment™)
### 🔨 Been working on Eaglercraft ever since 1.8.9
### 🎤 Holds the title for the second Eaglerbrother™ (first was AR-DEV-1)

## 👨‍💻 FlamePVPCodes
### 🌟 Elevated our website's quality
### 🌐 Significantly improved the Web Dev Console
### 🏆 Earned the "OP" status
### 🚀 Works on enhancing BtPlayzX's Eaglercraft Launcher
### 🧑‍💻 Knows all langs accept for java
### 🐛 Meticulously fixed bugs
### 💪 First code was skidded resent
### 🤼 Tries to bring the Eaglercraft community together
### 🔥 Founder Of FlameClient
### 🥇 Owned the achievement of knowing almost every code
### 🎤 Holds the title for the third Eaglerbrother™ (first was AR-DEV-1)

## 👨‍💻  Ink Boi-Kun
### 🌟 Elevated our website's quality
### 🏆 Earned the "OP" status
### 🤼 Tries to bring the Eaglercraft community together
### 🐛 Meticulously fixed bugs
### 🫠 Helped make graphics and designed logos
### 🪦 Owner and Founder of a DMCA'd Client
### 🚨 Has been working on Eaglercraft since Lax1Dude
### 🎤 Holds the title for the fourth Eaglerbrother™ (first was AR-DEV-1)


## **🚨 Mojang DMCA Notice 🚨*
### If you are willing to shut us down then PLEASE read BtPlayzX's DMCA complaint [here](https://github.com/EaglerDevs/Dear-Mojang-via-Eaglercraft)

### If you are still unconvinced, read Lax1Dude's heartfelt plea [here](https://github.com/lax1dude/eaglercraftx-1.8).
